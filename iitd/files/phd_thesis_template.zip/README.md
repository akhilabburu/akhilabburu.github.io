# IIT Delhi PhD Thesis Template

A LaTeX template for the IIT Delhi PhD thesis.

## Quick start (Overleaf)

1. **Open as Template** (or upload this folder as a new project).
2. Make sure the compiler is set to **pdfLaTeX** (Menu → Settings → Compiler).
3. Edit `_helpers/thesis-config.tex` — set your title, name, dept, supervisors,
   submission month/year, and pronoun.
4. Replace placeholder text in:
   - `frontmatter/dedication.tex`, `committee.tex`, `acknowledgement.tex`, `abstract-en.tex`
   - `frontmatter/symbols.tex`, `acronyms.tex` (or delete if unused)
   - `chapters/0X-*/chapter.tex`
   - `backmatter/publications.tex`, `biodata.tex`
5. Replace the dummy entries in `references.bib` with your own.
6. Click **Recompile**. The bibliography needs at least two passes — Overleaf
   handles this automatically.

## Quick start (local)

```bash
pdflatex main.tex
biber main
pdflatex main.tex
pdflatex main.tex
```

Run from the project root. Requires a TeX Live installation with biber.

## Hindi Saar (सार)

The Saar must be compiled separately because it needs **XeLaTeX** (for
Devanagari script and `polyglossia`).

1. Open `_helpers/saar.tex`. Replace the placeholder Hindi text with your
   abstract.
2. Switch the compiler to XeLaTeX (Menu → Settings → Compiler) — *temporarily*
   — and recompile only this file. The cleanest approach is a *separate*
   single-file Overleaf project containing only `saar.tex`.
3. Download the resulting PDF and place it at `frontmatter/saar.pdf` in the
   main project.
4. In `main.tex`, find the `Saar (Hindi Abstract)` block, delete the
   placeholder `\chapter*{सार (Saar)} ...` block, and uncomment the
   `\includepdf[...]{frontmatter/saar.pdf}` block immediately below it.
5. Switch the main project compiler back to **pdfLaTeX**.

If `Nakula` is unavailable on your TeX distribution, change the font line in
`_helpers/saar.tex` to `Mangal` or `Sanskrit2003`.

## Selective compilation (drafting one chapter)

In `main.tex`, uncomment the `\includeonly{...}` block (around line 60) and
keep only the chapter you are working on. Front-matter still compiles. This
dramatically speeds up Overleaf recompiles when drafting a single chapter.

## Customisation cheatsheet

| You want to change…              | Edit this file                          |
|----------------------------------|-----------------------------------------|
| Title, author, dept, dates       | `_helpers/thesis-config.tex`            |
| Supervisor name(s)               | `_helpers/thesis-config.tex`            |
| Pronoun in certificate           | `\thesisgender` in `thesis-config.tex`  |
| Bibliography style               | `style=apa` in `_helpers/thesis-packages.tex` |
| Line spacing                     | `\onehalfspacing` in `thesis-config.tex`|
| Page margins                     | `geometry` block in `thesis-packages.tex` |
| Chapter list / order             | `\include{...}` block in `main.tex`     |
| Add a new chapter directory      | Create dir + add to `\graphicspath`     |
| Theorem/lemma environments       | Uncomment block in `thesis-config.tex`  |
| Add `siunitx`, `glossaries`, etc.| Add to `_helpers/thesis-packages.tex`   |

## Repository layout

```
<project-root>/
├── main.tex                          # document root, compile this
├── references.bib                    # all citations live here
├── figures/                          # drop all your figures here
├── _helpers/
│   ├── thesis-config.tex             # ALL metadata (edit me!)
│   ├── thesis-packages.tex           # \usepackage declarations
│   ├── saar.tex                      # standalone XeLaTeX Hindi abstract
│   ├── iitd_logo_bw.png              # for cover/title pages
│   └── iitd_logo.svg                 # vector logo (optional)
├── frontmatter/
│   ├── dedication.tex
│   ├── committee.tex
│   ├── certificate.tex
│   ├── acknowledgement.tex
│   ├── abstract-en.tex
│   ├── symbols.tex
│   └── acronyms.tex
├── chapters/
│   ├── 01-introduction/chapter.tex
│   ├── 02-literature-review/chapter.tex
│   ├── 03-methodology/chapter.tex
│   ├── 04-results/chapter.tex
│   ├── 05-discussion/chapter.tex
│   └── 06-conclusion/chapter.tex
├── appendices/
│   └── appendix-a.tex
└── backmatter/
    ├── publications.tex
    └── biodata.tex
```

Drop all your figures in the top-level `figures/` directory and reference them
by filename only (no path): `\includegraphics{my-figure}`.

## Conventions

- **Cross-references:** use `\cref{...}` and `\Cref{...}` (cleveref). Don't
  hand-write `Figure~\ref{...}`.
- **Citations:** use `\cite`, `\parencite`, or `\textcite` from biblatex.
  Don't use natbib commands like `\citep`/`\citet` directly — they are
  remapped via the `natbib=true` option but new code should prefer biblatex.
- **Figures:** include without an extension and without a path:
  `\includegraphics{my-figure}` finds `chapters/0X-*/figures/my-figure.pdf`.
- **Date in certificate:** type the actual date by hand. Don't use `\today` —
  it changes on every compile and will be wrong on the printed copy.

## Known issues / gotchas

- **Inkscape SVG logo:** the template uses the rasterised `iitd_logo_bw.png`,
  not the SVG. The SVG is included for reference but rendering it inside
  LaTeX requires Inkscape on the system PATH (Overleaf provides this).
- **Blank pages:** `openright` + `twoside` produces blank versos when needed.
  This is correct for printed binding. To suppress on the soft copy, add
  `\usepackage{emptypage}` to `thesis-packages.tex`.
- **Saar font:** Overleaf provides several Devanagari fonts; if `Nakula`
  fails, try `Mangal` or `Sanskrit2003`.
- **Bibliography passes:** if citations show as `[?]`, run pdfLaTeX → biber
  → pdfLaTeX → pdfLaTeX, or just press Recompile twice on Overleaf.
- **Margins for binding:** if your dept asks for a wider gutter, increase
  `inner=25mm` in `thesis-packages.tex` to e.g. `inner=35mm`.

## IITD compliance

This template implements the page order and front-matter set out in the IITD
PhD thesis guidelines. Verify the *current* version of the guidelines with
your department before final submission.

## License

Distributed under the **Creative Commons Attribution 4.0 International (CC-BY 4.0)** license. Do whatever you want.